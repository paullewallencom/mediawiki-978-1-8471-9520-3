********************************************
MediaWiki Skins Design
********************************************

Chapter 1 - No Code
Chapter 2 - Code Present
Chapter 3 - Code Present
Chapter 4 - Code Present
Chapter 5 - Code Present
Chapter 6 - No Code
Chapter 7 - Code Present
Chapter 8 - Code Present
Chapter 9 - No Code
Chapter 10 - Code Present
Appendix A - No Code


This folder contains text files that contain the codes for the respective chapters.